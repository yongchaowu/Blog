var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);


app.get("/login", function(req,res){
	res.send('<?xml version="1.0"  encoding="UTF-8"?>\n<MTConnectDevices xmlns:m="urn:mtconnect.org:MTConnectDevices:1.3" xmlns="urn:mtconnect.org:MTConnectDevices:1.3" xsi:schemaLocation="urn:mtconnect.org:MTConnectDevices:1.3 http://www.mtconnect.org/media/39431/mtconnectdevices_12xsd.xml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><Header assetBufferSize="4049" assetCount="0" bufferSize="130000" instanceId="1" creationTime="2009-11-13T02:31:40" sender="local" version="1.3"/><Devices><Device id="d1" uuid="Mazak" name="Mazak"><Description>Mazak HCN</Description><DataItems><DataItem id="avail" type="AVAILABILITY" category="EVENT"/></DataItems></Device></Devices></MTConnectDevices>')
});

app.get("/current", function(req,res){
	res.send('<?xml version="1.0"  encoding="UTF-8"?>\n<MTConnectDevices xmlns:m="urn:mtconnect.org:MTConnectDevices:1.3" xmlns="urn:mtconnect.org:MTConnectDevices:1.3" xsi:schemaLocation="urn:mtconnect.org:MTConnectDevices:1.3 http://www.mtconnect.org/media/39431/mtconnectdevices_12xsd.xml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><Header assetBufferSize="4049" assetCount="0" bufferSize="130000" instanceId="1" creationTime="2009-11-13T02:31:40" sender="local" version="1.3"/><Devices><Device id="d1" uuid="Mazak" name="Mazak"><Description>Mazak HCN</Description><DataItems><DataItem id="avail" type="AVAILABILITY" category="EVENT"/></DataItems></Device></Devices></MTConnectDevices>')
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;
